package project;

import java.io.Serializable;

public class Website implements Serializable {
    public String date;
    public String URL;
    public String title;
    public String time;

    public Website(String date, String URL, String title, String time) {
        this.date = date;
        this.URL = URL;
        this.title = title;
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Website{" +
                "date='" + date + '\'' +
                ", URL='" + URL + '\'' +
                ", title='" + title + '\'' +
                ", time='" + time + '\'' +
                '}';
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
