package project;
import java.util.Scanner;
import java.io.*;
public class HashTables<E> implements Serializable {
    private ArrayStack[] hashArray;
    private int arraySize;
    public HashTables(int size){
        arraySize=size;
        hashArray=new ArrayStack[arraySize];
        for(int j=0;j<hashArray.length;j++){
            hashArray[j]=new ArrayStack();
        }
    }

    public class Entry<E> {
        int key;
        E data;

        public Entry(int k, E d) {
            key = k;
            data = d;

        }

        public void display() {
            System.out.print(key + ":");
            System.out.println(data);
        }
    }

    public class Node<E> {
        Node next;
        private int key;
        private E data;

        public Node(int k, E d, Node<E> n) {
            key = k;
            data = d;
            next = n;
        }
    }

        private static int s = 0;




        //--------------------------------------------------
        public boolean isFull() {
            for (int i = 0; i < hashArray.length; i++)
                if (hashArray[i].equals(null) )
                    return false;
            return true;

        }


        // -------------------------------------------------------------
        public int hashFunc(int key) {
            return key % hashArray.length;
        }

        public void addWebsite(String Date, String URL, String Title, String Time) {
            int key=Integer.parseInt(Date);
            Website newWebsite = new Website(Date, URL, Title, Time);
            int hashVal=hashFunc(key);
            hashArray[hashVal].push(newWebsite);
        }

        public void deleteWebsite(String date, String URL) {
            ArrayStack<Website>temp2=new ArrayStack<>();
            int key = Integer.parseInt(date);
            int hashVal = hashFunc(key);
            boolean found=false;
            while(!hashArray[hashVal].isEmpty()){
                Website temp=(Website)hashArray[hashVal].top();
                if (temp.URL.equals(URL)) {
                    hashArray[hashVal].pop();
                    System.out.println("The website " + temp.title + " has been deleted ");
                    found=true;
                }
                temp2.push((Website)hashArray[hashVal].pop());
            }
            while(!temp2.isEmpty()){
                hashArray[hashVal].push(temp2.pop());
            }
            if(!found){
                System.out.println("The website is not found");
            }
            }

        public void searchWebsite(String url) {
            boolean found=false;
            ArrayStack<E>temp2=new ArrayStack<>();
            for(ArrayStack entry:hashArray){
                while(!entry.isEmpty()){
                        Website temp=(Website)entry.top();
                        if(temp.URL.equals(url)){
                            System.out.println("Website date "+temp.date+" Website time "+temp.time);
                            found=true;
                        }
                        temp2.push((E)entry.pop());
                }
                while(!temp2.isEmpty()){
                    entry.push(temp2.pop());
                }
            }
            if(!found){
                System.out.println("The website was not found");
            }
        }

        public void displayAllWebsites(String date) {
            ArrayStack<Website> temp2 = new ArrayStack<>();
            System.out.println("Websites visited on " + date + ":");
            int key = Integer.parseInt(date);
            int hashVal = hashFunc(key);
            if (!hashArray[hashVal].isEmpty()) {
                while (!hashArray[hashVal].isEmpty()) {
                    Website temp = (Website) hashArray[hashVal].pop();
                    System.out.println("Website title: " + temp.title + " Website time: " + temp.time + " Website date " + temp.date);
                    temp2.push(temp);
                }

                while (!temp2.isEmpty()) {
                    hashArray[hashVal].push(temp2.pop());
                }
            }
            else{
                System.out.println("Stack is empty");
            }
        }

    public static void main(String[]args) {
        HashTables<project.Website> hashWebsite=new HashTables<>(1000);
        try {
            String path="websitehistory.dat";
            File fileObj = new File(path);
            if(fileObj.exists()){
                ObjectInputStream in;
                in = new ObjectInputStream(new FileInputStream(path));
                hashWebsite = (HashTables<project.Website>) in.readObject();
            }
            else {
                hashWebsite = new HashTables(1000);
            }

            Scanner kb = new Scanner(System.in);
            int choice = 0;

            while (choice!=5 ) {
                System.out.format("Enter your choice:\r\n" + "1- Add Website\r\n" + "2- Delete Website\r\n"
                        + "3- Search Website\r\n" + "4- Print Websites \r\n" + "5- Exit\nyour choice... ");
                choice = kb.nextInt();
                if (choice==1) {
                    System.out.println("Please enter the date the website was visited...");

                    String date = kb.next();

                    System.out.println("Please enter the URl...");

                    String URl = kb.next();

                    System.out.println("Please enter the title of the website...");
                    String title = kb.next();

                    System.out.println("Please enter the time the website was visited...");
                    String time = kb.next();

                }
                if (choice==2) {
                    System.out.println("Please enter the date the website was visited...");
                    String date2 = kb.next();

                    System.out.println("Please enter the URl...");
                    String URl2 = kb.next();


                }
                if (choice==3) {
                    System.out.println("Please ente" + "r the URl...");
                    String URl3 = kb.next();

                }
                if (choice==4) {
                    System.out.println("Please enter the date the website was visited...");
                    String date4 = kb.next();


                }
            }
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path));
            out.writeObject(hashWebsite);
            out.close();
            System.out.println("Exited...");
        }


        catch (EOFException eof) {
            System.out.println("Reached end of file.");
        }
        catch (IOException | ClassNotFoundException exception) {
            System.out.println(exception.getStackTrace());
        }
    }
    }

