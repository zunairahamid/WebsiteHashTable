package project;
import java.io.*;
import java.util.Scanner;
public class Test {
    public static void main(String[]args) throws Exception {
        HashTables<Website>hashWebsite;
        ObjectInputStream in;
		ObjectOutputStream out;
        try {
            in = new ObjectInputStream(new FileInputStream("websitehistory.dat"));
            hashWebsite= (HashTables<Website>) in.readObject();
        } catch (Exception e) {
        	hashWebsite= new HashTables<>(1000);
        }
        
            Scanner kb = new Scanner(System.in);
            int choice = 0;

            while (choice!=5 ) {
                System.out.format("Enter your choice:\r\n" + "1- Add Website\r\n" + "2- Delete Website\r\n"
                        + "3- Search Website\r\n" + "4- Print Websites \r\n" + "5- Exit\nyour choice... ");
                choice = kb.nextInt();
                if (choice==1) {
                    System.out.println("Please enter the date the website was visited...");

                    String date = kb.next();

                    System.out.println("Please enter the URl...");

                    String URl = kb.next();

                    System.out.println("Please enter the title of the website...");
                    String title = kb.next();

                    System.out.println("Please enter the time the website was visited...");
                    String time = kb.next();
                    hashWebsite.addWebsite(date,URl,title,time);
                }
                if (choice==2) {
                    System.out.println("Please enter the date the website was visited...");
                    String date2 = kb.next();

                    System.out.println("Please enter the URl...");
                    String URl2 = kb.next();
                    hashWebsite.deleteWebsite(date2,URl2);
                }
                if (choice==3) {
                    System.out.println("Please enter the URl...");
                    String URl3 = kb.next();
                    hashWebsite.searchWebsite(URl3);
                }
                if (choice==4) {
                    System.out.println("Please enter the date the website was visited...");
                    String date4 = kb.next();
                    hashWebsite.displayAllWebsites(date4);
                }
            }
            out = new ObjectOutputStream(new FileOutputStream("websitehistory.dat"));
            out.writeObject(hashWebsite);
            out.close();
            System.out.println("Exited...");
          
        }

   
}
